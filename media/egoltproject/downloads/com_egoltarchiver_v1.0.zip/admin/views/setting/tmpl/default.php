<?php
/**
 * @package   	Egolt Search & Archive
 * @link 		http://www.egolt.com
 * @copyright 	Copyright (C) Egolt www.egolt.com
 * @author    	Soheil Novinfard
 * @license    	GNU/GPL 2
 *
 * Name:			Egolt Search & Archive
 * License:    		GNU/GPL 2
 * Project Page: 	http://www.egolt.com/products/egoltarchiver
 */
 
defined('_JEXEC') or die('Restricted access');
?>
<p><iframe src="index.php?option=com_config&controller=component&component=com_egoltarchiver&amp;path=" width="100%" height="1655px" name="Egolt Search & Archive - Setting">
  <p><a rel="{handler: 'iframe', size: {x: 570, y: 500}}" href="index.php?option=com_config&amp;controller=component&amp;component=com_egoltarchiver&amp;path=" class="modal"></a></p>
</iframe>
</p>