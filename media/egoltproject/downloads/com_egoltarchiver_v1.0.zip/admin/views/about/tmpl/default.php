<?php
/**
 * @package   	Egolt Search & Archive
 * @link 		http://www.egolt.com
 * @copyright 	Copyright (C) Egolt www.egolt.com
 * @author    	Soheil Novinfard
 * @license    	GNU/GPL 2
 *
 * Name:			Egolt Search & Archive
 * License:    		GNU/GPL 2
 * Project Page: 	http://www.egolt.com/products/egoltarchiver
 */
 
defined('_JEXEC') or die('Restricted access');
$lang =& JFactory::getLanguage();
$lang_tag = $lang->getTag();
?>
<table class="adminform">
<tr>
<td valign="center" width="25%">
		<center>
			<br/>
			<img src="components/com_egoltarchiver/assets/images/egoltarchiver_big.png"></div>
				<div class="jpane-slider content">
			<div class="inner-about" >
				<div class="aversion"><?php echo JText::_('COM_EGOLTARCHIVER_VERSION') ?> 1.0</div>
				<div class="adownload"><a href="http://www.egolt.com/products/egoltarchiver" target="_blank"><?php echo JText::_('COM_EGOLTARCHIVER_DOWNLOADS') ?></a></div>
				<div class="adocumentation"><a href="http://www.egolt.com/products/egoltarchiver" target="_blank"><?php echo JText::_('COM_EGOLTARCHIVER_DOCUMENTS') ?></a></div>
				<div class="ademo"><a href="http://www.egolt.com/products/egoltarchiver" target="_blank"><?php echo JText::_('COM_EGOLTARCHIVER_DEMOS') ?></a></div>
				<div class="aforum"><a href="http://www.egolt.com/products/egoltarchiver" target="_blank"><?php echo JText::_('COM_EGOLTARCHIVER_SUPPORT') ?></a></div>
				<div class="alicense">
					<?php echo JText::_('COM_EGOLTARCHIVER_LIC_UNDER') ?> <a href="http://www.gnu.org/licenses/gpl-2.0.html" target="_blank"><?php echo JText::_('COM_EGOLTARCHIVER_LIC_GPL') ?></a>
				</div>
			</div>
		</div>
		</center>
</td>
<td valign="top" width="50%">
	<div class="panel">
		<h3 class="jpane-toggler title" id="cpanel-panel-popular"><span><?php echo JText::_('COM_EGOLTARCHIVER_TITLE'); ?></span></h3>
		<p style="text-align:justify;padding:20px;line-height:30px;" >
			<?php echo JText::_('COM_EGOLTARCHIVER_FULL_DESC'); ?>
		</p>
		<ul style="line-height:25px;" >
		<?php echo JText::_('COM_EGOLTARCHIVER_DESC'); ?>
		</ul>
		
	</div>
</td>
<td valign="center" width="25%">
		<center>
		<img src="components/com_egoltarchiver/assets/images/egolt.png"><br/><br/>
		&copy; <?php echo JText::_('COM_EGOLTARCHIVER_POWERED_BY') ?> <a href="http://www.egolt.com" target="_blank">
			<?php if($lang_tag == 'fa-IR') echo "ايگلت"; else echo "Egolt";?>		
		</a><br/><br/>
			<?php if($lang_tag == 'fa-IR') echo "سهيل نوين فرد"; else echo "Soheil Novinfard";?>
		<br/><br/>
		<a href="http://www.egolt.com" target="_blank">www.egolt.com</a><br/><br/>
		2009 - 2012<br/>
		</center>
</td>
</tr>
</table>
	