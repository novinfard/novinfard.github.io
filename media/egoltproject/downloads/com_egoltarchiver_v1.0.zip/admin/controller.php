<?php
/**
 * @package   	Egolt Search & Archive
 * @link 		http://www.egolt.com
 * @copyright 	Copyright (C) Egolt www.egolt.com
 * @author    	Soheil Novinfard
 * @license    	GNU/GPL 2
 *
 * Name:			Egolt Search & Archive
 * License:    		GNU/GPL 2
 * Project Page: 	http://www.egolt.com/products/egoltarchiver
 */
 
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport('joomla.application.component.controller');

class EgoltArchiverController extends JController
{
    /**
     * Method to display the view
     *
     * @access    public
     */
    function display()
    {		
        parent::display();
		EgoltArchiverHelper::setEnv('COM_EGOLTARCHIVER_CONTROL_PANEL');
    }
	
    function setting()
    {
    	JRequest::setVar( 'view', 'setting' );
	    parent::display();
		EgoltArchiverHelper::setEnv('COM_EGOLTARCHIVER_SETTING');
    }
	
    function about()
    {
    	JRequest::setVar( 'view', 'about' );
	    parent::display();
		EgoltArchiverHelper::setEnv('COM_EGOLTARCHIVER_ABOUT_PRODUCT');
    }

}
