<?php
/**
 * @package   	Egolt Search & Archive
 * @link 		http://www.egolt.com
 * @license    	GNU/GPL
 *
 * Name:			Egolt Search & Archive
 * License:    		GNU/GPL
 * Project Page: 	http://www.egolt.com/products/egoltarchiver
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

// require helper file
JLoader::register('EgoltArchiverHelper', JPATH_COMPONENT . DS . 'helpers' . DS . 'egoltarchiver.php');

// Require the base controller
require_once( JPATH_COMPONENT.DS.'controller.php' );

// Require specific controller if requested
if($controller = JRequest::getWord('controller')) 
{
    $path = JPATH_COMPONENT.DS.'controllers'.DS.$controller.'.php';
    
	if (file_exists($path)) 
	{
        require_once $path;
    } 
	else 
	{
        $controller = '';
    }
}

// Create the controller
$classname    = 'EgoltArchiverController'.$controller;
$controller   = new $classname( );

// Perform the Request task
$controller->execute(JRequest::getVar('task'));

// Redirect if set by the controller
$controller->redirect();

?>