<?php
/**
 * @package   	Egolt Search & Archive
 * @link 		http://www.egolt.com
 * @copyright 	Copyright (C) Egolt www.egolt.com
 * @author    	Soheil Novinfard
 * @license    	GNU/GPL 2
 *
 * Name:			Egolt Search & Archive
 * License:    		GNU/GPL 2
 * Project Page: 	http://www.egolt.com/products/egoltarchiver
 */
 
// No direct access to this file
defined('_JEXEC') or die;
 
/**
 * egoltarchiver component helper.
 */
abstract class EgoltArchiverHelper
{
	/**
	 * Configure the environment.
	 */
	public static function setEnv($active) 
	{
		// set title bar
		$egolt_title = JText::_( 'COM_EGOLTARCHIVER' );
		if ($active != 'COM_EGOLTARCHIVER_CONTROL_PANEL') {
			$egolt_title .=' - [ '.JText::_($active).' ]';
		}
        JToolBarHelper::title($egolt_title ,'egoltarchiver');

		// set sub-menus with active menu decleration
		JSubMenuHelper::addEntry(JText::_('COM_EGOLTARCHIVER_CONTROL_PANEL'),'index.php?option=com_egoltarchiver', $active == 'COM_EGOLTARCHIVER_CONTROL_PANEL');
		JSubMenuHelper::addEntry(JText::_('COM_EGOLTARCHIVER_SETTING'),'index.php?option=com_egoltarchiver&task=setting', $active == 'COM_EGOLTARCHIVER_SETTING');
		JSubMenuHelper::addEntry(JText::_('COM_EGOLTARCHIVER_ABOUT_PRODUCT'),'index.php?option=com_egoltarchiver&task=about', $active == 'COM_EGOLTARCHIVER_ABOUT_PRODUCT');
		
		// set some global property
		$document = JFactory::getDocument();
		$document->addStyleDeclaration('.icon-48-egoltarchiver 
		{background-image: url(components/com_egoltarchiver/assets/images/egoltarchiver.png);}');
		$document->setTitle(JText::_('COM_EGOLTARCHIVER').' - '.JText::_($active));	
	}
	
	public static function setSal($tp = null)
	{
		if (sha1('egolt') === '2e3340a60b208dd180664060422e299f1c42a2e6') 
		{
			if($tp)
				echo base64_decode( 'PGNlbnRlcj48c21hbGw+PHNtYWxsPjxhIGhyZWY9Imh0dHA6Ly93d3cuZWdvbHQuY29tIiB0YXJnZXQ9Il9ibGFuayIgPlBvd2VyZWQgYnkgRWdvbHQgU2VhcmNoICYgQXJjaGl2ZTwvYT48L3NtYWxsPjwvc21hbGw+PC9jZW50ZXI+PC9kaXY+' );
			else
				return 'PC9kaXY+PGNlbnRlcj48YSBocmVmPSJodHRwOi8vd3d3LmVnb2x0LmNvbSIgdGFyZ2V0PSJfYmxhbmsiPlBvd2VyZWQgYnkgRWdvbHQgUHJvamVjdCBQdWJsaXNoZXI8L2E+PC9jZW5LLAS+';			
		}
	}
	
}
