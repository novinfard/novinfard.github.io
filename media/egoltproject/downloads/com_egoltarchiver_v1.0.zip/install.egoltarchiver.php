<?php
/**
 * @package   	Egolt Search & Archive
 * @link 		http://www.egolt.com
 * @copyright 	Copyright (C) Egolt www.egolt.com
 * @author    	Soheil Novinfard
 * @license    	GNU/GPL 2
 *
 * Name:			Egolt Search & Archive
 * License:    		GNU/GPL 2
 * Project Page: 	http://www.egolt.com/products/egoltarchiver
 */

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

function com_install() 
{
	$language = JFactory::getLanguage();
	$language->load('com_egoltarchiver', JPATH_ADMINISTRATOR);
	$app = JFactory::getApplication();
	$link = 'index.php?option=com_egoltarchiver&view=about';
	$msg = JText::_('COM_EGOLTARCHIVER_INSTALL_MSG');
	// $msg = 'Egolt Seach & Archiver installed!';
	$app->redirect($link, $msg, $msgType='message');
	return true;
}