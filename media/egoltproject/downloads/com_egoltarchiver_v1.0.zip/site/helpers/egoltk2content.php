<?php
/**
 * @package   	Egolt Search & Archive
 * @link 		http://www.egolt.com
 * @copyright 	Copyright (C) Egolt www.egolt.com
 * @author    	Soheil Novinfard
 * @license    	GNU/GPL 2
 *
 * Name:			Egolt Search & Archive
 * License:    		GNU/GPL 2
 * Project Page: 	http://www.egolt.com/products/egoltarchiver
 */
 
// no direct access
defined('_JEXEC') or die('Restricted access');

require_once (JPATH_SITE.DS.'components'.DS.'com_k2'.DS.'helpers'.DS.'route.php');
require_once (JPATH_SITE.DS.'components'.DS.'com_k2'.DS.'helpers'.DS.'utilities.php');

class EgoltK2ContentHelper {
  function hasChildren($id) {

    $user = &JFactory::getUser();
    $aid = (int) $user->get('aid');
    $id = (int) $id;
    $db = &JFactory::getDBO();
    $query = "SELECT * FROM #__k2_categories  WHERE parent={$id} AND published=1 AND trash=0 AND access<={$aid} ";
    $db->setQuery($query);
    $rows = $db->loadObjectList();
    if ($db->getErrorNum()) {
      echo $db->stderr();
      return false;
    }

    if (count($rows)) {
      return true;
    } else {
      return false;
    }
  }

  function treerecurse(&$params, $id = 0, $level = 0, $begin = false) {

    static $output;
    if ($begin) {
      $output = '';
    }

    $root_id = (int) $params->get('root_id');
    $end_level = $params->get('end_level', NULL);
	$id = (int) $id;
    $catid = JRequest::getInt('id');
    $option = JRequest::getCmd('option');
    $view = JRequest::getCmd('view');

    $user = &JFactory::getUser();
    $aid = (int) $user->get('aid');
    $db = &JFactory::getDBO();

    switch ($params->get('categoriesListOrdering')) {

      case 'alpha':
        $orderby = 'name';
        break;

      case 'ralpha':
        $orderby = 'name DESC';
        break;

      case 'order':
        $orderby = 'ordering';
        break;

      case 'reversedefault':
        $orderby = 'id DESC';
        break;

      default:
        $orderby = 'id ASC';
        break;
    }

    if (($root_id != 0) && ($level == 0)) {
      $query = "SELECT * FROM #__k2_categories WHERE parent={$root_id} AND published=1 AND trash=0 AND access<={$aid} ORDER BY {$orderby}";

    } else {
      $query = "SELECT * FROM #__k2_categories WHERE parent={$id} AND published=1 AND trash=0 AND access<={$aid} ORDER BY {$orderby}";
    }

    $db->setQuery($query);
    $rows = $db->loadObjectList();
    if ($db->getErrorNum()) {
      echo $db->stderr();
      return false;
    }

    if ($level < intval($end_level) || is_null($end_level)) {
      $output .= '<ul class="level'.$level.'">';
      foreach ($rows as $row) {
        if ($params->get('categoriesListItemsCounter')) {
          $row->numOfItems = ' ('.EgoltK2ContentHelper::countCategoryItems($row->id).')';
        } else {
          $row->numOfItems = '';
        }

        if (($option == 'com_k2') && ($view == 'itemlist') && ($catid == $row->id)) {
          $active = ' class="activeCategory"';
        } else {
          $active = '';
        }

        if (EgoltK2ContentHelper::hasChildren($row->id)) {

          $output .= '<li'.$active.'><a href="'.urldecode(JRoute::_(K2HelperRoute::getCategoryRoute($row->id.':'.urlencode($row->alias)))).'"><span>'.$row->name.$row->numOfItems.'</span></a>';
          EgoltK2ContentHelper::treerecurse($params, $row->id, $level + 1);
          $output .= '</li>';
        } else {
          $output .= '<li'.$active.'><a href="'.urldecode(JRoute::_(K2HelperRoute::getCategoryRoute($row->id.':'.urlencode($row->alias)))).'"><span>'.$row->name.$row->numOfItems.'</span></a></li>';
        }
      }
      $output .= '</ul>';
    }

    return $output;
  }

  function treeselectbox($default = null, $id = 0, $level = 0) {

    $option = JRequest::getCmd('option');
    $view = JRequest::getCmd('view');
    $category = JRequest::getInt('id');
	$id = (int) $id;


	function cats($id, $level, & $arr) {
		$user = &JFactory::getUser();
		$aid = (int) $user->get('aid');
		$db = &JFactory::getDBO();
		$params = &JComponentHelper::getParams('com_egoltarchiver');
		$root_id = (int) $params->get('root_k2', 0);		
		
		if (($root_id != 0) && ($level == 0)) {
		  $query = "SELECT * FROM #__k2_categories WHERE parent={$root_id} AND published=1 AND trash=0 AND access<={$aid} ORDER BY ordering ";
		} else {
		  $query = "SELECT * FROM #__k2_categories WHERE parent={$id} AND published=1 AND trash=0 AND access<={$aid} ORDER BY ordering ";
		}

		$db->setQuery($query);
		$rows = $db->loadObjectList();
		if ($db->getErrorNum()) {
		  echo $db->stderr();
		  return false;
		}

		if ($level == 0) {
			$arr[0] = JText::_('ALL CATEGORIES') ;	
		}
		$indent = "";
		for ($i = 0; $i < $level; $i++) {
		  $indent .= '&ndash; ';
		}

		foreach ($rows as $row) {
		  if (EgoltK2ContentHelper::hasChildren($row->id)) {
			$arr[$row->id] = $indent.$row->name ;
			cats($row->id, $level + 1, $arr);
		  } else {
			$arr[$row->id] = $indent.$row->name ;
		  }
		}
	}
	
	cats($id, $level, $arr);
	
    if ($level == 0) {
		foreach($arr as $key => $val) {
			$arr2[] = JHTML::_('select.option', $key, $val) ;			
		}
		return  JHTML::_('select.genericlist', $arr2, 'catlist', null, 'value', 'text',$default);
    }
  }


  function getCatChild($catid) {

    static $arrstr;
    $user = &JFactory::getUser();
    $aid = (int) $user->get('aid');
    $catid = (int) $catid;
    $db = &JFactory::getDBO();
    $query = "SELECT * FROM #__k2_categories WHERE parent={$catid} AND published=1 AND trash=0 AND access<={$aid} ORDER BY ordering ";
    $db->setQuery($query);
    $rows = $db->loadObjectList();
    if ($db->getErrorNum()) {
      echo $db->stderr();
      return false;
    }
    foreach ($rows as $row) {
		if(isset($arrstr )){
			$arrstr .= '-' . $row->id;
		}
		else {
			$arrstr = $row->id;
		}
		if (EgoltK2ContentHelper::hasChildren($row->id)) {
			EgoltK2ContentHelper::getCatChild($row->id);
      }
    }
    return $arrstr;
  }

}
