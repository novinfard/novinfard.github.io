<?php
/**
 * @package   	Egolt Search & Archive
 * @link 		http://www.egolt.com
 * @copyright 	Copyright (C) Egolt www.egolt.com
 * @author    	Soheil Novinfard
 * @license    	GNU/GPL 2
 *
 * Name:			Egolt Search & Archive
 * License:    		GNU/GPL 2
 * Project Page: 	http://www.egolt.com/products/egoltarchiver
 */
 
// No direct access to this file
defined('_JEXEC') or die;
 
abstract class EgoltSessionHelper
{
	public static function setSess() 
	{
		$session = JFactory::getSession(); 
		
		if($rbtab = JRequest::getVar('rbtab')) {
			$egolt_archiver['rbtab'] = $rbtab;		
		}

		if(JRequest::getVar('startd')) {
			$lang =& JFactory::getLanguage();
			$lang_tag = $lang->getTag();		
		
			if($lang_tag == 'fa-IR') {
				$startdate = EgoltDateHelper::toGRdate(JRequest::getVar('starty'), JRequest::getVar('startm'), JRequest::getVar('startd'));		
				$enddate = EgoltDateHelper::toGRdate(JRequest::getVar('endy'), JRequest::getVar('endm'), JRequest::getVar('endd'));				
			}
			else {
				$startdate = array (JRequest::getVar('starty'), JRequest::getVar('startm'), JRequest::getVar('startd'));
				$enddate = array (JRequest::getVar('endy'), JRequest::getVar('endm'), JRequest::getVar('endd'));
			}

			//start date
			$startdate =  implode('-', $startdate);
			$egolt_archiver['startdate'] = $startdate;
			
			//end date
			$enddate = implode('-', $enddate);
			$egolt_archiver['enddate'] = $enddate;
			
		}
		if($duration = JRequest::getVar('duration')) {
			$egolt_archiver['duration'] = $duration;
		}
		if($cat = JRequest::getVar('catlist')) {
			$egolt_archiver['catlist'] = $cat;
		}
		if($search_str = JRequest::getVar('search_str')) {
			$egolt_archiver['like_str'] = $search_str;
			if(JRequest::getVar('exact_search')) {
				$egolt_archiver['exact_like'] = 1;
			}
		}
		if($search_str = JRequest::getVar('not_search_str')) {
			$egolt_archiver['not_like_str'] = $search_str;
			if(JRequest::getVar('exact_not_search')) {
				$egolt_archiver['exact_not_like'] = 1;
			}
		}
		
		$mainframe =& JFactory::getApplication();
		$menu = & JSite::getMenu();
		$menu_item = $menu->getActive()->id;
		if(isset($egolt_archiver))
		{
			//set sessions
			$session->set('egolt_archiver', $egolt_archiver);
			
			//redirect to first search page
			$mainframe->redirect('index.php?option=com_egoltarchiver&Itemid=' . $menu_item);
		}
		
		if(JRequest::getVar('searchall')) {
			//clear search session
			$session->clear('egolt_archiver');
		
			//redirect to first search page
			$mainframe->redirect('index.php?option=com_egoltarchiver&Itemid=' . $menu_item);
		}
		
		
	}
}