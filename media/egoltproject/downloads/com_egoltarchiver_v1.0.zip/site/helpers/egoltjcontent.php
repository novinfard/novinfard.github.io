<?php
/**
 * @package   	Egolt Search & Archive
 * @link 		http://www.egolt.com
 * @copyright 	Copyright (C) Egolt www.egolt.com
 * @author    	Soheil Novinfard
 * @license    	GNU/GPL 2
 *
 * Name:			Egolt Search & Archive
 * License:    		GNU/GPL 2
 * Project Page: 	http://www.egolt.com/products/egoltarchiver
 */
 
// No direct access to this file
defined('_JEXEC') or die;
 

abstract class EgoltJContentHelper
{
	public static function catSelect($default = null) 
	{
		$params = &JComponentHelper::getParams('com_egoltarchiver');
		if($params->get('category_use_allcat', 1)) {
			$arr[] = JHTML::_('select.option', 0, JText::_('COM_EGOLTARCHIVER_ALL_CATEGORIES')) ;	
		}
		
		if($params->get('category_use_nocat')) {
			$arr[] = JHTML::_('select.option', 'sec0', JText::_('COM_EGOLTARCHIVER_NO_CATEGORIES')) ;	
			$inc_suffix = '';
		}
		else {
			$inc_suffix = ',0';		
		}
	
		$db	=& JFactory::getDBO();
		
		$query = 
		' SELECT *' .
		' FROM #__sections' .
		' WHERE published = 1';
		
		if($sec_inc = $params->get('section_inc')) {			
			$query .= " AND id IN ({$sec_inc} {$inc_suffix})";
		}		
		
		if($sec_not_inc = $params->get('section_not_inc')) {			
			$query .= " AND id NOT IN ({$sec_not_inc})";
		}
		
		$db->setQuery($query);
		$rows = $db->loadObjectList();
		foreach($rows as $row)
		{
			if($params->get('category_use_sec', '1')) {
				$arr[] = JHTML::_('select.option', 'sec'.$row->id, $row->title) ;
			}
			
			$query2 = 
			' SELECT *' .
			' FROM #__categories' .
			' WHERE published = 1' .
			' AND section = ' . $row ->id ;
			
			if($cat_inc = $params->get('category_inc')) {			
				$query2 .= " AND id IN ({$cat_inc} {$inc_suffix})";
			}		
			
			if($cat_not_inc = $params->get('category_not_inc')) {			
				$query2 .= " AND id NOT IN ({$cat_not_inc})";
			}
			
			$db->setQuery($query2);
			$rows2 = $db->loadObjectList();
			foreach($rows2 as $row2)
			{
				if($params->get('category_use_cat', '1')) {
					$arr[] = JHTML::_('select.option', $row2->id, '&ndash; ' . $row2->title) ;
				}
			}
		}
		
		return  JHTML::_('select.genericlist', $arr, 'catlist', null, 'value', 'text',$default);

	}
	public function unicodeSub($str, $end, $start = 0)
	{
		preg_match_all("/./u", $str, $ar);
		return join("",array_slice($ar[0],$start,$end));
	}
	public static function linkString($id, $title, $catid ,$sectionid = null, $embed = 0) 
	{
		$params = &JComponentHelper::getParams('com_egoltarchiver');
		if($params->get('content_service', 'jc') == 'jc') {
			require_once(JPATH_SITE.DS.'components'.DS.'com_content'.DS.'helpers'.DS.'route.php');
			if(!$embed) {
				$db	=& JFactory::getDBO();
				$query = 
				' SELECT *' .
				' FROM #__content' .
				' WHERE id = '.$id ;
				$db->setQuery($query);
				$rows = $db->loadObjectList();
				foreach ( $rows as $row )
				{
					$title = $row->title;
					$catid = $row->catid ;
					$sectionid = $row->sectionid ;
				}
			}
			$url = JRoute::_(ContentHelperRoute::getArticleRoute($id, $catid, $sectionid));
		}
		else if($params->get('content_service', 'jc') == 'k2') {
			require_once(JPATH_SITE.DS.'components'.DS.'com_k2'.DS.'helpers'.DS.'route.php');
			$url = JRoute::_(K2HelperRoute::getItemRoute($id, $catid));
		}
		return '<a href="' . $url . '" >' . $title . '</a>';
	}
}