//Create an array
  var allPageTags = new Array();

function doSomethingWithClasses(theClass) {
	//Populate the array with all the page tags
    var allPageTags=document.getElementsByTagName("*");
	
	//Cycle through the tags using a for loop
    for (var i=0; i<allPageTags.length; i++) {
	
		//Pick out the tags with our class name
      if (allPageTags[i].className==theClass) {
	  
		//Manipulate this in whatever way you want
        allPageTags[i].style.display='none';
      }
    }
}

function Show(ids) {
  doSomethingWithClasses('RBtnTab');

  var obj = document.getElementById(ids);
  if (obj.style.display != 'block') { obj.style.display = 'block'; }
                               else { obj.style.display = 'none'; }
}