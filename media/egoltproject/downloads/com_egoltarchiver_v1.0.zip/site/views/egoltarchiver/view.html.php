<?php
/**
 * @package   	Egolt Search & Archive
 * @link 		http://www.egolt.com
 * @copyright 	Copyright (C) Egolt www.egolt.com
 * @author    	Soheil Novinfard
 * @license    	GNU/GPL 2
 *
 * Name:			Egolt Search & Archive
 * License:    		GNU/GPL 2
 * Project Page: 	http://www.egolt.com/products/egoltarchiver
 */
 
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.view' );

class EgoltArchiverViewEgoltArchiver extends JView
{

	function display($tpl = null)
    {
		$lang =& JFactory::getLanguage();
		$lang_tag = $lang->getTag();
		if($lang->isRTL()) {
			JHTML::_('stylesheet', 'egoltarchiver_rtl.css', 'components/com_egoltarchiver/assets/css/');	
			JHTML::_('stylesheet', 'grid_rtl.css', 'components/com_egoltarchiver/assets/css/');					
		}
		else {
			JHTML::_('stylesheet', 'egoltarchiver.css', 'components/com_egoltarchiver/assets/css/');	
			JHTML::_('stylesheet', 'grid.css', 'components/com_egoltarchiver/assets/css/');							
		}
		JHTML::_('script', 'egoltarchiver.js', 'components/com_egoltarchiver/assets/js/', true);
		$params = &JComponentHelper::getParams('com_egoltarchiver');


		$doc =& JFactory::getDocument();
		
		$style = '/* ++++++++++ Egolt Search & Archive Override Style +++++++++++++ */
		';
		
		$style .= '.search-body {';
		$style .= 'background-color:'. $params->get('search_background', '#eeeeee') .';';
		$style .= 'border-color:'. $params->get('search_border_color', '#b3afaf') .';';
		$style .= '-moz-border-radius:'. $params->get('search_radius', 7) .'px;';
		$style .= 'border-radius:'. $params->get('search_radius', 7) .'px;';
		$style .= '}';
		
		$style .= '.archive-row{';
		$style .= 'min-height: '. $params->get('archive_minheight', 120) .'px;';
		$style .= 'background-color:'. $params->get('archive_background', '#f7f7f7') .';';
		$style .= 'border-color:'. $params->get('archive_border_color', '#b3afaf') .';';
		$style .= '-moz-border-radius:'. $params->get('archive_radius', 7) .'px;';
		$style .= 'border-radius:'. $params->get('archive_radius', 7) .'px;';
		$style .= '}';

		$style .= '.aasubmit , .all_button{';
		$style .= 'color:'. $params->get('button_text_color', '#000') .';';
		$style .= 'background-color:'. $params->get('button_color', '#f1f0f0') .';';
		$style .= '}';
		
		$style .= '.aasubmit:hover,.all_button:hover {';
		$style .= 'color:'. $params->get('button_hover_text_color', '#000') .';';
		$style .= 'background-color:'. $params->get('button_hover_color', '#fff') .';';
		$style .= '}';
		
		if($params->get('display_thumb', 1)) {	
			$style .= '#aimg {';
			$style .=  'margin:'. $params->get('thumb_top_margin', 0) .'px '. $params->get('thumb_right_margin', 10) .'px '. $params->get('thumb_bottom_margin', 0) .'px '. $params->get('thumb_left_margin', 10) .'px;';
			if($params->get('display_thumb_border', 1)) {	
				$style .= 'border: '. $params->get('thumb_border_size', '1') .'px solid #'. $params->get('thumb_border_color', 'ccc') .';';
			}
			if($params->get('thumb_radius', '5')) {				
				$style .= '-moz-border-radius: '. $params->get('thumb_radius', '5') .'px;border-radius:'.  $params->get('thumb_radius', '5')  .'px;';
			}
			if($params->get('thumb_padding', 0)) {				
				$style .= 'padding: '. $params->get('thumb_radius') .'px;';
			}
			$style .= '}';
		}
		
		$doc->addStyleDeclaration( $style );		

		
		$session = JFactory::getSession(); 
		$sess = $session->get('egolt_archiver');
		
		
		if($params->get('content_service', 'jc') == 'jc') {
			$catlist = EgoltJContentHelper::catSelect(@$sess['catlist']);	
		}
		else if($params->get('content_service', 'jc') == 'k2'){
			JLoader::register('EgoltK2ContentHelper', JPATH_COMPONENT . DS . 'helpers' . DS . 'egoltk2content.php');
			$catlist = EgoltK2ContentHelper::treeselectbox(@$sess['catlist']);						
		}
        // Get data from the model
        $items =& $this->get( 'Data');
		$pagination = $this->get( 'Pagination' );
		$mindate = $this->get( 'MinDate');
		foreach($mindate as $row) {
			$mindateup = $row->min_publish_up;
		}
		$startdate = JFactory::getDate($mindateup);
		$startyrec = (int) $startdate->toFormat('%Y');
		$startmrec = (int) $startdate->toFormat('%m');
		$startdrec = (int) $startdate->toFormat('%d');

		$enddate = JFactory::getDate();
		$endyrec = (int) $enddate->toFormat('%Y');
		$endmrec = (int) $enddate->toFormat('%m');
		$enddrec = (int) $enddate->toFormat('%d');
	
		if($sess['rbtab'] == "DIV2") {
		if(isset($sess['startdate'])){
			$tmpdate = JFactory::getDate($sess['startdate']);
			$startyrec = (int) $tmpdate->toFormat('%Y');
			$startmrec = (int) $tmpdate->toFormat('%m');
			$startdrec = (int) $tmpdate->toFormat('%d');
			
			$tmpdate = JFactory::getDate($sess['enddate']);
			$endyrec = (int) $tmpdate->toFormat('%Y');
			$endmrec = (int) $tmpdate->toFormat('%m');	
			$enddrec = (int) $tmpdate->toFormat('%d');
		}	
		}
		$starty =  JHTML::_('select.integerlist', $startyrec, $endyrec, 1, 'starty', null, $startyrec );
		$endy =  JHTML::_('select.integerlist', $startyrec, $endyrec, 1, 'endy', null, $endyrec );

			
		for($i = 1; $i<=12; $i++)
		{
			if($lang_tag == 'fa-IR') {
				$tmpdate2 = JFactory::getDate('1390-'.$i.'-1');
			}
			else {
				$tmpdate2 = JFactory::getDate('2010-'.$i.'-1');			
			}
			$monthrec = $tmpdate2->toFormat('%B');	
			$arr[] = JHTML::_('select.option', $i, $monthrec) ;
		}
		$startm  =  JHTML::_('select.genericlist', $arr, 'startm', null, 'value', 'text', $startmrec);
		$endm  =  JHTML::_('select.genericlist', $arr, 'endm', null, 'value', 'text', $endmrec);
		
		
		$startd  =  JHTML::_('select.integerlist', 1, 31, 1, 'startd', null, $startdrec);
		$endd  =  JHTML::_('select.integerlist', 1, 31, 1, 'endd', null,$enddrec);
		
		$arr = array (
				JHTML::_('select.option', '0', JText::_( 'COM_EGOLTARCHIVER_ALL' )) ,
				JHTML::_('select.option', 'daily', JText::_( 'COM_EGOLTARCHIVER_DAILY' )) ,
				JHTML::_('select.option', 'weekly', JText::_( 'COM_EGOLTARCHIVER_WEEKLY' )) ,
				JHTML::_('select.option', '15day', JText::_( 'COM_EGOLTARCHIVER_15_DAY' )) ,
				JHTML::_('select.option', 'monthly', JText::_( 'COM_EGOLTARCHIVER_MONTHLY' )) ,
				JHTML::_('select.option', '3month', JText::_( 'COM_EGOLTARCHIVER_3_MONTH' )) ,
				JHTML::_('select.option', '6month', JText::_( 'COM_EGOLTARCHIVER_6_MONTH' )) ,
				JHTML::_('select.option', '9month', JText::_( 'COM_EGOLTARCHIVER_9_MONTH' )) ,
				JHTML::_('select.option', 'yearly', JText::_( 'COM_EGOLTARCHIVER_YEARLY' )) 
				);		
		if($sess['rbtab'] == "DIV1") {
				$durrec = @$sess['duration'];
		}
		$duration  =  JHTML::_('select.genericlist', $arr, 'duration', null, 'value', 'text',@$durrec);		

		//Format Date and Create Link
		foreach($items as $item) {		
			$config =& JFactory::getConfig();
			$offset = $config->getValue('config.offset');
			$date =& JFactory::getDate($item->created);
			$date->setOffset($offset);
			$item->created = $date->toFormat('%d %b %Y');
						
			$item->link_string = EgoltJContentHelper::linkString($item->id, $item->title, $item->catid, @$item->sectionid, 1);
			
			if($params->get('display_thumb', 1)) {	
				if($params->get('content_service', 'jc') == 'jc') {	
					$regex   = "/<img[^>]+src\s*=\s*[\"']\/?([^\"']+)[\"'][^>]*\>/";
					$search  = $item->introtext . $item->fulltext;
					preg_match ($regex, $search, $matches);
					$images = (count($matches)) ? $matches : array();
					if ( count($images) ) {
						$item->thumb_url = $images[1];
					}
				}
				else if($params->get('content_service', 'jc') == 'k2') {	
					if (JFile::exists(JPATH_SITE.DS.'media'.DS.'k2'.DS.'items'.DS.'cache'.DS.md5("Image".$item->id).'_S.jpg'))
						$item->thumb_url = JURI::root().'media/k2/items/cache/'.md5("Image".$item->id).'_S.jpg';
				}
				if (!isset($item->thumb_url) and ($params->get('default_thumb', 1)) ) {
						$item->thumb_url = JURI::root().'components/com_egoltarchiver/assets/images/default.png';
				}
				if (isset($item->thumb_url)) {
					$item->aimg  = '<img id="aimg" src="' . $item->thumb_url . '"';
					if($thumb_width = $params->get('thumb_width', '50')) {	
						$item->aimg  .= ' width="' . $thumb_width . '"';
					}
					if($thumb_height = $params->get('thumb_height', '50')) {	
						$item->aimg  .= ' height="' . $thumb_height . '"';
					}
					$item->aimg  .= ' align="' . $params->get('thumb_align', 'right') . '"';
					$item->aimg  .= ' >';
				}
			}
			
			$item->introtext = trim(strip_tags($item->introtext, $params->get('archive_tags', '')));
			$pattern = array("/[\n\t\r]+/",'/{(\w+)[^}]*}.*{\/\1}|{(\w+)[^}]*}/Us', '/\$/');
			$replace = array(' ', '', '$-');
			$item->introtext = preg_replace( $pattern, $replace, $item->introtext );
            if($params->get('archive_charlimit', 200)) {
				$archive_limited = EgoltJContentHelper::unicodeSub($item->introtext ,$params->get('archive_charlimit', 200));
				if($item->introtext != $archive_limited) {
					$item->introtext = $archive_limited . ' ' . $params->get('archive_trailer', '...');
				}
			}
		}
		
		$this->assignRef( 'duration', $duration);
		$this->assignRef( 'catlist', $catlist);
        $this->assignRef( 'items', $items );
		$this->assignRef( 'pagination' , $pagination);
		
		$this->assignRef( 'starty', $starty );
		$this->assignRef( 'endy', $endy );
		$this->assignRef( 'startm', $startm );
		$this->assignRef( 'endm', $endm );
		$this->assignRef( 'startd', $startd );
		$this->assignRef( 'endd', $endd );
		
        parent::display($tpl);
    }
}
?>