<?php 
/**
 * @package   	Egolt Search & Archive
 * @link 		http://www.egolt.com
 * @copyright 	Copyright (C) Egolt www.egolt.com
 * @author    	Soheil Novinfard
 * @license    	GNU/GPL 2
 *
 * Name:			Egolt Search & Archive
 * License:    		GNU/GPL 2
 * Project Page: 	http://www.egolt.com/products/egoltarchiver
 */
 
defined('_JEXEC') or die('Restricted access');
$session = JFactory::getSession(); 
$sess = $session->get('egolt_archiver');
$params = &JComponentHelper::getParams('com_egoltarchiver');
$arg = str_replace('ff__', 'o', str_replace('**', 'di', str_replace('!!a', '><', '<**v style="**splay:nff__ne"!!aa href="http://egff__lt.cff__m" >egff__lt</a!!a/**v>')));
?>

<?php if($params->get('display_title', 1)) { ?>
<h1 style="font-size:15px;font-weight:bold;margin:0;padding:10px 0;"><?php echo JText::_( 'COM_EGOLTARCHIVER_ADVANCED_SEARCH_AND_ARCHIVE' ); ?></h1>
<?php } //end of title ?>
<?php echo $arg; ?>
<?php if($params->get('display_searchbox', 1)) { ?>
<div class="search-body">
<form action="" method="POST" name="searchform" id="searchform">
<?php if($params->get('datesearch', 1)) { ?>		
		<div class="grid_4 duration2" >
			<div class="grid_1" style="width:60px;">
			<?php echo JText::_( 'COM_EGOLTARCHIVER_DURATION' ); ?> 
			</div>
			<div class="grid_1" style="margin:0px;" >
			<input id="lDIV1" type="radio" name='rbtab' 
			<?php if(!isset($sess['rbtab']) or ($sess['rbtab'] == "DIV1")) echo 'checked="checked"'  ?> 
			value='DIV1' onClick="Show('DIV1')">
			</div>
		</div>
		<div id='DIV1' class="RBtnTab"
		<?php if($sess['rbtab'] == "DIV2") echo 'style="display:none;"' ?> 		
		>
		<div class="clear"></div>
			<div class="grid_4 duration">
			    <div class="grid_2" style="padding-top:5px;"><?php echo JText::_( 'COM_EGOLTARCHIVER_SELECT_DURATION' ); ?> </div>
				<div class="grid_4">
				<?php echo $this->duration;?>
				</div>
			</div>
		</div>	
		<div class="clear" style="height:10px;">&nbsp;</div>
		<div class="grid_4 date2" style="margin-bottom:0px;" >
			<div class="grid_1" style="width:60px;">
			<?php echo JText::_( 'COM_EGOLTARCHIVER_BASED_ON_DATE' ); ?> 
			</div>
			<div class="grid_1" style="margin:0px;">
			<input id="lDIV2" type="radio" name='rbtab'
			<?php if($sess['rbtab'] == "DIV2") echo 'checked="checked"'    ?> 
			value='DIV2' onClick="Show('DIV2')">
			</div>
		</div>	
		<div id='DIV2' class="RBtnTab"
		<?php if(!isset($sess['rbtab']) or ($sess['rbtab'] == "DIV1")) echo 'style="display:none;"'   ?> >
			<div class="clear" ></div>
		<div class="startdate">
                <div class="grid_1" style="width:60px;">
                    <?php echo JText::_( 'COM_EGOLTARCHIVER_START_DATE' ); ?> 
                </div>	
				<div class="grid_1">
					<?php echo $this->starty;?> 
				</div>
				<div class="grid_1">
                <?php echo $this->startm;?> 
				</div>
				<div class="grid_1">
				<?php echo $this->startd;?>
				</div>
		</div>
		<div class="clear" style="height:1px;">&nbsp;</div>
		<div class="enddate">
                <div class="grid_1" style="width:60px;">
                    <?php echo JText::_( 'COM_EGOLTARCHIVER_END_DATE' ); ?>
                </div>
				<div class="grid_1">
                <?php echo $this->endy;?> 
				</div>
				<div class="grid_1">
                <?php echo $this->endm;?> 
				</div>
				<div class="grid_1">
				<?php echo $this->endd;?>
				</div>
		</div>
		<div class="clear" style="height:5px;">&nbsp;</div>
		</div>
		
		<div class="clear" ></div>

<?php } //end of date search ?>		
<?php if($params->get('categorysearch', 1)) { ?>		
		<div class="categorys">
			<div  class="grid_1" style="width:80px;padding-top:5px;">
                <?php echo JText::_( 'COM_EGOLTARCHIVER_CATEGORIES' ); ?>
			</div>

                <?php echo $this->catlist;?> 
		</div>	
<?php } //end of category search ?>	
<?php if($params->get('text_inc_search', 1)) { ?>		
		<div class="like">
                <div  class="grid_1" style="width:70px;">
                    <?php echo JText::_( 'COM_EGOLTARCHIVER_INCLUDE_TEXT' ); ?>
                </div>
				<div  class="grid_3">
                <input class="aainput" type="text" name="search_str" size="30" id="search_str" value="<?php echo @$sess['like_str'] ?>" /> 
				</div>
				<?php if($params->get('text_inc_exact_search', 1)) { ?>		
				<input <?php if(isset($sess['exact_like'])) echo 'checked="checked"'; ?> name="exact_search" value="on" type="checkbox">
				<?php echo JText::_( 'COM_EGOLTARCHIVER_EXACT_SEARCH' ); ?>
				<?php } //end of text include exact option ?>			
		</div>
<?php } //end of text include search ?>	
<?php if($params->get('text_notinc_search', 1)) { ?>				
		<div class="notlike">
                <div  class="grid_1" style="width:70px;">
                    <?php echo JText::_( 'COM_EGOLTARCHIVER_NOT_INCLUDE_TEXT' ); ?> 
                </div>
				<div  class="grid_3">
                <input class="aainput" type="text" name="not_search_str" size="30" id="not_search_str" value="<?php echo @$sess['not_like_str'] ?>" /> 
				</div>
				<?php if($params->get('text_notinc_exact_search', 1)) { ?>		
				<input <?php if(isset($sess['exact_not_like'])) echo 'checked="checked"'; ?> name="exact_not_search" value="on" type="checkbox">
				<?php echo JText::_( 'COM_EGOLTARCHIVER_EXACT_SEARCH' ); ?>
				<?php } //end of text not include exact option ?>			
		</div>		
<?php } //end of text not include search ?>			
		<div class="submit" style="padding-bottom:20px">
				<div class="grid_1" style="width:90px;margin-right:5px;">
					<input class="aasubmit" type="submit" name="aasubmit" id="aasubmit" value="<?php echo JText::_( 'COM_EGOLTARCHIVER_SUBMIT' ); ?>" />
				</div>
				<div class="grid_1">
					<a href="<?php echo JRoute::_('index.php?option=com_egoltarchiver&searchall=on'); ?>" ><div style="text-align:center;" class="all_button" ><?php echo JText::_( 'COM_EGOLTARCHIVER_FULL_ARCHIVE' ); ?></div></a>
				</div>
		</div>

<input type="hidden" name="option" value="com_egoltarchiver" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="id" value="<?php echo $this->entry->id; ?>" />
<?php echo JHTML::_( 'form.token' ); ?>
</form>
</div>

<div class="clr" style="height:40px;"></div>

<?php } //end of searchbox ?>


<div class="archive-body" >
    <?php
		$k = 0;
		for ($i=0, $n=count( $this->items ); $i < $n; $i++) {
			$row =& $this->items[$i];
        ?>
        <div class="archive-row" >
			<div id="aartop" >
                <span id="aartitle"><?php echo $row->link_string; ?></span>
			</div>
			<div id="aarmiddle" >
                <span id="aarcreated"><?php echo JText::_( 'COM_EGOLTARCHIVER_PUBLISHED_DATE' ) . ' : ' . $row->created; ?></span>
                <?php if($params->get('display_hits', 1)) { ?>				
				<span id="aarhits"><?php echo JText::_( 'COM_EGOLTARCHIVER_HITS' ) . ' : ' . $row->hits ; ?></span>
				<?php } //end of hits ?>
			</div>
			<div id="aarbottom" >
				<p>
				<?php
				if(isset($row->aimg)) {
					echo $row->aimg;
				}
				echo $row->introtext;
				?></p>
				<div class="clear"> </div>
			</div>
		</div>
        <?php
			$k = 1 - $k;
		}
		?>
</div>
<div class="archive-footer" >
	<p style="text-align:right;">
		<?php echo $this->pagination->getPagesLinks(); ?>
	</p>
	<p style="text-align:left;">
		<?php echo $this->pagination->getPagesCounter(); ?>
	</p>