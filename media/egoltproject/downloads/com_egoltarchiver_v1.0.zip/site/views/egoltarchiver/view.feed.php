<?php
/**
 * @package   	Egolt Search & Archive
 * @link 		http://www.egolt.com
 * @copyright 	Copyright (C) Egolt www.egolt.com
 * @author    	Soheil Novinfard
 * @license    	GNU/GPL 2
 *
 * Name:			Egolt Search & Archive
 * License:    		GNU/GPL 2
 * Project Page: 	http://www.egolt.com/products/egoltarchiver
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );

jimport( 'joomla.application.component.view');


class EgoltArchiverViewEgoltArchiver extends JView
{
	function display()
	{
		global $mainframe;
		$doc =& JFactory::getDocument();
		$params =& $mainframe->getParams();
		$feedEmail = (@$mainframe->getCfg('feed_email')) ? $mainframe->getCfg('feed_email') : 'author';
		$siteEmail = $mainframe->getCfg('mailfrom');
		
		// Get some data from the model
		JRequest::setVar('limit', $mainframe->getCfg('feed_limit'));


		require_once(JPATH_SITE.DS.'components'.DS.'com_content'.DS.'helpers'.DS.'route.php');		
	
        // Get data from the model
        $items =& $this->get( 'Data');
		$pagination = $this->get( 'Pagination' );	

		//Format Date and Create Link
		foreach($items as $row) {		
		
			$config =& JFactory::getConfig();
			$offset = $config->getValue('config.offset');
			$date =& JFactory::getDate($row->created);
			$date->setOffset($offset);
			$row->created = $date->toFormat('%d %b %Y');
			
			// strip html from feed item title
			$title = $this->escape( $row->title );
			$title = html_entity_decode( $title );

			// url link to article
			// & used instead of &amp; as this is converted by feed creator
			$link = JRoute::_(ContentHelperRoute::getArticleRoute($row->id, $row->catid, $row->sectionid));

			// strip html from feed item description text
			$description	= ($params->get('feed_summary', 0) ? $row->introtext.$row->fulltext : $row->introtext);
			$author			= $row->created_by_alias ? $row->created_by_alias : $row->author;

			// load individual item creator class
			$item = new JFeedItem();
			$item->title 		= $title;
			$item->link 		= $link;
			$item->description 	= $description;
			$item->date			= $row->created;
			$item->category   	= $row->category;
			$item->author		= $author;
			if ($feedEmail == 'site') {
				$item->authorEmail = $siteEmail;
			}
			else {
				$item->authorEmail = $row->author_email;
			}

			// loads item info into rss array
			$doc->addItem( $item );
		}


		$doc->link = '';


	}
}
