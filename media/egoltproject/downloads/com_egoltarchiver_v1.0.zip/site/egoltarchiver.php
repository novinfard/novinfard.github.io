<?php
/**
 * @package   	Egolt Search & Archive
 * @link 		http://www.egolt.com
 * @copyright 	Copyright (C) Egolt www.egolt.com
 * @author    	Soheil Novinfard
 * @license    	GNU/GPL 2
 *
 * Name:			Egolt Search & Archive
 * License:    		GNU/GPL 2
 * Project Page: 	http://www.egolt.com/products/egoltarchiver
 */

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

// require helper file
JLoader::register('EgoltDateHelper', JPATH_COMPONENT . DS . 'helpers' . DS . 'egoltdate.php');

// require helper file
JLoader::register('EgoltSessionHelper', JPATH_COMPONENT . DS . 'helpers' . DS . 'egoltsession.php');
EgoltSessionHelper::setSess();

// require helper file
JLoader::register('EgoltJContentHelper', JPATH_COMPONENT . DS . 'helpers' . DS . 'egoltjcontent.php');

// Require the base controller
require_once( JPATH_COMPONENT.DS.'controller.php' );

// Require specific controller if requested
if ($controller = JRequest::getWord('controller')) 
{
    $path = JPATH_COMPONENT.DS.'controllers'.DS.$controller.'.php';
    if (file_exists($path)) 
	{
        require_once $path;
    } 
	else 
	{
        $controller = '';
    }
}

// Create the controller
$classname    = 'EgoltArchiverController'.$controller;
$controller   = new $classname();

// Perform the Request task
$controller->execute(JRequest::getVar('task'));

// Redirect if set by the controller
$controller->redirect();
