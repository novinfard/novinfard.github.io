<?php
/**
 * @package   	Egolt Search & Archive
 * @link 		http://www.egolt.com
 * @copyright 	Copyright (C) Egolt www.egolt.com
 * @author    	Soheil Novinfard
 * @license    	GNU/GPL 2
 *
 * Name:			Egolt Search & Archive
 * License:    		GNU/GPL 2
 * Project Page: 	http://www.egolt.com/products/egoltarchiver
 */

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.model' );

class EgoltArchiverModelEgoltArchiver extends JModel
{

	var $_total;
	var $_pagination;
	
	function __construct()
	{
		parent::__construct();
							
		global $mainframe;
		$config = JFactory::getConfig();

		// Get the pagination request variables
		$limit		= $mainframe->getUserStateFromRequest( 'global.list.limit', 'limit', $mainframe->getCfg('list_limit'), 'int' );
		$limitstart = JRequest::getVar('limitstart', 0, '', 'int');
		// In case limit has been changed, adjust limitstart accordingly
		$limitstart = ($limit != 0 ? (floor($limitstart / $limit) * $limit) : 0);

		$this->setState('limit', $limit);
		$this->setState('limitstart', $limitstart);	
		
	}
	
	/**
	 * Returns the query
	 * @return string The query to be used to retrieve the rows from the database
	 */
	function _buildQuery()
	{
		$user = &JFactory::getUser();
		$aid = (int) $user->get('aid');
		$db =& JFactory::getDBO();
		$session = JFactory::getSession(); 
		$sess =& $session->get('egolt_archiver');
		
		$params = &JComponentHelper::getParams('com_egoltarchiver');
		
		if($params->get('content_service','jc') == 'jc') {			
		
			$query = 'SELECT * FROM #__content'
			. ' WHERE state = 1 AND access<='. $aid;
			
			if(!$params->get('category_use_nocat','1')) {			
				$query .= " AND sectionid!= 0";
				$inc_suffix = '';
			}
			else {
				$inc_suffix = ',0';
			}

			if($cat_inc = $params->get('category_inc')) {			
				$query .= " AND catid IN ({$cat_inc} {$inc_suffix})";
			}		
			
			if($cat_not_inc = $params->get('category_not_inc')) {			
				$query .= " AND catid NOT IN ({$cat_not_inc})";
			}
			
			if($sec_inc = $params->get('section_inc')) {			
				$query .= " AND sectionid IN ({$sec_inc} {$inc_suffix})";
			}		
			
			if($sec_not_inc = $params->get('section_not_inc')) {			
				$query .= " AND sectionid NOT IN ({$sec_not_inc})";
			}
			
			$nullDate	= $db->getNullDate();
			$date =& JFactory::getDate();
			$now = $date->toMySQL();	
			$query .= ' AND ( publish_up = '.$db->Quote($nullDate).' OR publish_up <= '.$db->Quote($now).' )' ;
			$query .= ' AND ( publish_down = '.$db->Quote($nullDate).' OR publish_down >= '.$db->Quote($now).' )' ;	
			
			if($sess['rbtab'] == "DIV2") {
			if(isset($sess['startdate'])) {
				$query .= " AND created BETWEEN '{$sess['startdate']} 0:0' AND '{$sess['enddate']} 23:59'";
			}
			}
			if($sess['rbtab'] == "DIV1") {
			if(isset($sess['duration'])) {
				switch($sess['duration']) {
					case 'daily':
					$dur_param = 'INTERVAL 1 DAY';
					break;
					case 'weekly':
					$dur_param = 'INTERVAL 7 DAY';
					break;
					case '15day':
					$dur_param = 'INTERVAL 15 DAY';
					break;
					case 'monthly':
					$dur_param = 'INTERVAL 1 MONTH';
					break;
					case '3month':
					$dur_param = 'INTERVAL 3 MONTH';
					break;
					case '6month':
					$dur_param = 'INTERVAL 6 MONTH';
					break;
					case '9month':
					$dur_param = 'INTERVAL 9 MONTH';
					break;
					case 'yearly':
					$dur_param = 'INTERVAL 1 YEAR';
					break;
				}
				$query .= " AND created BETWEEN DATE_SUB(CURDATE(), {$dur_param}) AND CURDATE()";
			}
			}
			if(isset($sess['catlist'])) {
				$cat = $sess['catlist'];
				if(strpos($cat,'sec') === false) {
					$query .= " AND catid = " . $cat;
				}
				else {
					$query .= " AND sectionid = " . substr($cat, 3);
				}
			}
			if(isset($sess['like_str'])) {
				$search_str = $sess['like_str'] ;
				if(isset($sess['exact_like'])) {
					$str = $search_str;
				}
				else {
					$str = "%{$search_str}%";
				}
				$query .= " AND (title LIKE '{$str}' OR introtext LIKE '{$str}' OR #__content.fulltext LIKE '{$str}' ) ";
			}
			if(isset($sess['not_like_str'])) {
				$not_search_str = $sess['not_like_str'] ;
				if(JRequest::getVar('exact_not_search')) {
					$str = $not_search_str;
				}
				else {
					$str = "%{$not_search_str}%";
				}
				$query .= " AND title NOT LIKE '{$str}' ";

			}

		}
		else if($params->get('content_service', 'jc') == 'k2') {
			
			JLoader::register('EgoltK2ContentHelper', JPATH_COMPONENT . DS . 'helpers' . DS . 'egoltk2content.php');
			
			 $query = 'SELECT * FROM #__k2_items'
			 . ' WHERE published  = 1 AND trash=0 AND access<='. $aid;
			
			if($cat_inc = $params->get('category_inc')) {			
				$query .= " AND catid IN ({$cat_inc})";
			}	
			
			if($cat_not_inc = $params->get('category_not_inc')) {			
				$query .= " AND catid NOT IN ({$cat_not_inc})";
			}
			
			$nullDate	= $db->getNullDate();
			$date =& JFactory::getDate();
			$now = $date->toMySQL();	
			$query .= ' AND ( publish_up = '.$db->Quote($nullDate).' OR publish_up <= '.$db->Quote($now).' )' ;
			$query .= ' AND ( publish_down = '.$db->Quote($nullDate).' OR publish_down >= '.$db->Quote($now).' )' ;	
			
			if($sess['rbtab'] == "DIV2") {
			if(isset($sess['startdate'])) {
				$query .= " AND created BETWEEN '{$sess['startdate']} 0:0' AND '{$sess['enddate']} 23:59'";
			}
			}
			if($sess['rbtab'] == "DIV1") {
			if(isset($sess['duration'])) {
				switch($sess['duration']) {
					case 'daily':
					$dur_param = 'INTERVAL 1 DAY';
					break;
					case 'weekly':
					$dur_param = 'INTERVAL 7 DAY';
					break;
					case '15day':
					$dur_param = 'INTERVAL 15 DAY';
					break;
					case 'monthly':
					$dur_param = 'INTERVAL 1 MONTH';
					break;
					case '3month':
					$dur_param = 'INTERVAL 3 MONTH';
					break;
					case '6month':
					$dur_param = 'INTERVAL 6 MONTH';
					break;
					case '9month':
					$dur_param = 'INTERVAL 9 MONTH';
					break;
					case 'yearly':
					$dur_param = 'INTERVAL 1 YEAR';
					break;
				}
				$query .= " AND created BETWEEN DATE_SUB(CURDATE(), {$dur_param}) AND CURDATE()";
			}
			}
			if(isset($sess['catlist'])) {
				$cat = $sess['catlist'];
				$catchild = EgoltK2ContentHelper::getCatChild($sess['catlist']);
				if(isset($catchild)) {
					$catchild = explode('-', $catchild);
					$catchild = array_unique($catchild);
					$catchild = implode(',', $catchild);
					$catsep   = $cat . ',' . $catchild ;
				}
				else {
					$catsep   = $cat ;				
				}
				$query .= " AND catid IN (" . $catsep . ")";
			}
			if(isset($sess['like_str'])) {
				$search_str = $sess['like_str'] ;
				if(isset($sess['exact_like'])) {
					$str = $search_str;
				}
				else {
					$str = "%{$search_str}%";
				}
				$query .= " AND (title LIKE '{$str}' OR introtext LIKE '{$str}' OR #__k2_items.fulltext LIKE '{$str}' ) ";
			}
			if(isset($sess['not_like_str'])) {
				$not_search_str = $sess['not_like_str'] ;
				if(JRequest::getVar('exact_not_search')) {
					$str = $not_search_str;
				}
				else {
					$str = "%{$not_search_str}%";
				}
				$query .= " AND title NOT LIKE '{$str}' ";
			}
		}
		$query .= " ORDER BY " . $params->get('order_type','id DESC');	

						
		return $query;
		
	}
	
	/**
	 * Retrieves the entrys
	 * @return array Array of objects containing the data from the database
	 */
	function getData()
	{
		// Lets load the data if it doesn't already exist
		if (empty( $this->_data )) {
			$query = $this->_buildQuery();
			$this->_data = $this->_getList( $query, $this->getState('limitstart'), $this->getState('limit') );
		}
		return $this->_data;
	}
	
	function getMindate()
	{
		$user = &JFactory::getUser();
		$aid = (int) $user->get('aid');
		$params = &JComponentHelper::getParams('com_egoltarchiver');
		if($params->get('content_service', 'jc') == 'jc') {
			$query = "SELECT MIN(created) as min_publish_up from #__content WHERE state=1 AND access<=".$aid;
		}
		else if($params->get('content_service', 'jc') == 'k2') {
			$query = "SELECT MIN(created) as min_publish_up from #__k2_items WHERE published=1  AND trash=0 AND access<=".$aid;	
		}
		$this->_data = $this->_getList($query);
		return $this->_data;
	}

	function getPagination()
	{
		if (empty($this->_pagination)) {
			jimport('joomla.html.pagination');
			$this->_pagination = new JPagination( $this->getTotal(), $this->getState('limitstart'), $this->getState('limit') );
		}
		return $this->_pagination;
	}
	
	/**
	 * Retrieves the count of entrys
	 * @return array Array of objects containing the data from the database
	 */
	function getTotal()
	{
		if (empty($this->_total)) {
			$query = $this->_buildQuery();
			$this->_total = $this->_getListCount($query);
		}
		return $this->_total;
	}

}
