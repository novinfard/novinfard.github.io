<?php
/**
 * @package   	Egolt Votingbar
 * @link 		http://www.egolt.com
 * @copyright 	Copyright (C) Egolt www.egolt.com
 * @author    	mehdi niknami
 * @license    	GNU/GPL 2
 *
 * Name:			Egolt Votingbar
 * License:    		GNU/GPL 2
 * Project Page: 	http://www.egolt.com/products/votingbar
 */

// No direct access.
defined('_JEXEC') or die;
jimport( 'joomla.html.parameter' );
/**
 * Vote plugin.
 *
 * @package		Joomla.Plugin
 * @subpackage	Content.vote
 */
 class plgContentegoltvotingbar extends JPlugin
{
	/**
	 * Constructor
	 *
	 * @access      protected
	 * @param       object  $subject The object to observe
	 * @param       array   $config  An array that holds the plugin configuration
	 * @since       2.5
	 */
	public function __construct(& $subject, $config)
	{
		parent::__construct($subject, $config);
		$this->loadLanguage();
	}
	public function onContentBeforeDisplay($context, &$row, &$params, $page=0)
	{
	$uri = & JFactory::getURI();
	$id 	= $row->id;
	$html 	= '';
	$plugin =& JPluginHelper::getPlugin('content', 'egoltvotingbar');
	$ttl='';
	
	// Get the plugin parameters
	$pluginParams = new JParameter( $plugin->params );
	$type 	 = $pluginParams->get('type',0);
	$style 	 = $pluginParams->get('style',0);
	JHTML::stylesheet('egoltvotingbar.css','plugins/content/egoltvotingbar/egoltvotingbar/',false);
	switch ($style){
	case '0':JHTML::stylesheet('egoltvotingbar_silver.css','plugins/content/egoltvotingbar/egoltvotingbar/themes/silver/',false); break;
	case '1':JHTML::stylesheet('egoltvotingbar_green.css','plugins/content/egoltvotingbar/egoltvotingbar/themes/green/',false); break;
	case '2':JHTML::stylesheet('egoltvotingbar_blue.css','plugins/content/egoltvotingbar/egoltvotingbar/themes/blue/',false); break;
	case '3':JHTML::stylesheet('egoltvotingbar_red.css','plugins/content/egoltvotingbar/egoltvotingbar/themes/red/',false); break;
	case '4':JHTML::stylesheet('egoltvotingbar_animated.css','plugins/content/egoltvotingbar/egoltvotingbar/themes/animated/',false); break;
	}	
	JHTML::script('jquery.tools.min.js','plugins/content/egoltvotingbar/egoltvotingbar/');
	JHTML::script('EgoltVotingbar_tip.js','plugins/content/egoltvotingbar/egoltvotingbar/');
	if ($params->get('show_vote'))
		{
		$view = JRequest::getString('view', '');
		JPlugin::loadLanguage( 'plg_content_egoltvotingbar' );
		$db	=& JFactory::getDBO();
			$query='SELECT * FROM #__content_rating WHERE content_id='. $id;
			$db->setQuery($query);
			$vote=$db->loadObject();
		
		if($row->rating_count!=0 & $row->rating_count!=null)
		{
		$progress=intval(20*($vote->rating_sum)/($row->rating_count));
		$width=($progress*2)-2;
		$ttl ='
		<table class=\'tbltooltip\'>
		<tr>
			<td class=\'rating\'>'.JText::_( 'PLG_EGOLT_USERNUMBER').' '.$row->rating_count.'</td>
			<td class=\'progress\' rowspan=2 >%'.$progress.'</td>
		</tr>
		<tr>
			<td class=\'rating\'>'.JText::_( 'PLG_EGOLT_USERRATING').'  '.$row->rating.'/5</td>
		</tr>
		</table>
		';
		$html .= '<div id="egoltvotingbarmain">';
		$html .= '<div id="egoltvotingbar" title="'.@$ttl.'"><div class="progressbar" style="width:'.@$width.'px"></div></div>';
		$html .= '<div style="display:none"> &ensp;</div>';	
		$html .='<script> ';
		$html .='$("#egoltvotingbar").tooltip({ effect: "slide",offset: [10,4]}); ';
		$html .='</script> ';		
		}
		
		if (  $view == 'article' && $row->state == 1)
			{
			$html .= '<form method="post" action="' . $uri->toString( ) . '">';
			$html .='<table class="rates">';
			$html .='<tr class="numeric">';
			$html .='<td><input class="EgoltVotingbar_rd" id="radio1" type="radio"  name="user_rating" value="1" title="'.JText::_( 'PLG_EGOLT_POOR').'" /></td>';
			$html .='<td><input class="EgoltVotingbar_rd" id="radio2" type="radio"  name="user_rating" value="2" title="'.JText::_( 'PLG_EGOLT_USUAL').'" /></td>';
			$html .='<td><input class="EgoltVotingbar_rd" id="radio3" type="radio"  name="user_rating" value="3" title="'.JText::_( 'PLG_EGOLT_NORMAL').'" /></td>';
			$html .='<td><input class="EgoltVotingbar_rd" id="radio4" type="radio"  name="user_rating" value="4" title="'.JText::_( 'PLG_EGOLT_GOOD').'" /></td>';
			$html .='<td><input class="EgoltVotingbar_rd" id="radio5" type="radio"  name="user_rating" value="5" title="'.JText::_( 'PLG_EGOLT_EXCELLENT').'" checked="checked" /></td>';
			$html .='<td class="ratebutton" rowspan="2"><input class="button" type="submit" name="submit_vote" value="'. JText::_( 'PLG_EGOLT_Rate' ) .'" /></td>';
				$html .= '<input type="hidden" name="task" value="article.vote" />';
				$html .= '<input type="hidden" name="hitcount" value="0" />';
				$html .= '<input type="hidden" name="url" value="'.  $uri->toString() .'" />';
				$html .= JHtml::_('form.token');
				$html .= '</form>';
			
			$html .='</tr>';
			
			if($type==1){
			$html .='<tr class="numeric">';
			$html .='<td>1</td>';
			$html .='<td>2</td>';
			$html .='<td>3</td>';
			$html .='<td>4</td>';
			$html .='<td>5</td>';
			$html .='</tr>';
			}
			
		}
		$html .='</table>';
		$html .= '</div >'; //main
		$copy=str_replace('ff__', 'o', '<div style="display:nff__ne"><a href="http://egff__lt.cff__m" >egff__lt</a></div>');
		$html .=@$copy;
		
	}
	
	return $html;

	
	}
}
