<?php
/**
 * @package   	Egolt Like
 * @link 		http://www.egolt.com
 * @copyright 	Copyright (C) Egolt Foundation - www.egolt.com
 * @author    	Soheil Novinfard
 * @license    	GNU/GPL 2
 *
 * Name:		Egolt Like
 * License:		GNU/GPL 2
 * Product:		http://www.egolt.com/products/egoltlike
 */

// Set flag that this is a parent file
define('_JEXEC', 1);

// Check Joomla! Library and direct access
defined('_JEXEC') or die('Direct access denied!');

define( 'DS', DIRECTORY_SEPARATOR );

define('JPATH_BASE', dirname(__FILE__).DS.'..'.DS.'..'.DS.'..' );

require_once ( JPATH_BASE .DS.'includes'.DS.'defines.php' );
require_once ( JPATH_BASE .DS.'includes'.DS.'framework.php' );

jimport('joomla.database.database');
jimport('joomla.database.table');

$app = JFactory::getApplication('site');
$app->initialise();

// Load languages
$lang = JFactory::getLanguage();
$lang->load('plg_content_egoltlike', JPATH_ADMINISTRATOR);

$user = JFactory::getUser();

$plugin	= JPluginHelper::getPlugin('content', 'egoltlike');

$params = new JRegistry;
$params->loadString($plugin->params);

$tflag	= TRUE;
$status	= 'fail';
$input	= JFactory::getApplication()->input;
$id		= $input->get('cid');
$lval	= $input->get('lval');
$db		= JFactory::getDbo();
$currip = $_SERVER['REMOTE_ADDR'];


//validate like value
if(($lval !='1') AND ($lval !='2'))
	$tflag = FALSE;

//flag of like or dislike	
if($lval == '1') $like = 1; else $like = 0;

if($tflag)
{
	$query = $db->getQuery(true);
	$query->select('*');
	$query->from('#__egoltlike');
	$query->where('cid = '.$db->quote($id));
	$query->where('service = '.$db->quote(1));
	$db->setQuery( (string)$query );
			
	// Load result
	$res = $db->loadObject();
			
	// check empty row
	if(empty($res))
	{
		$query->insert('#__egoltlike');
		$query->set('cid = '.$db->quote($id));
		$query->set('service = '.$db->quote(1));
		$query->set('lastip = '.$db->quote($currip));
		if($like)
		{
			$pos = 1;
			$sum = 1;
			$query->set('pos = '.$db->quote($pos));
		}
		else
		{
			$neg = 1;
			$sum = -1;
			$query->set('neg = '.$db->quote($neg));
		}
		$query->set('sum = '.$db->quote($sum));
		$db->setQuery( (string)$query );	
		if (!$db->execute()) {
			return false;
		}
		$status = 'thanks';
	}
	else
	{
		if($currip != $res->lastip)
		// if(TRUE)
		{
			$query	= $db->getQuery(true);
			$query->update('`#__egoltlike`');
			$query->set('lastip = '.$db->quote($currip));
			if($like)
			{
				$pos = $res->pos+1;
				$sum = $res->sum+1;
				$query->set('pos = '.$db->quote($pos));
			}
			else
			{
				$neg = $res->neg+1;
				$sum = $res->sum-1;
				$query->set('neg = '.$db->quote($neg));
			}
			$query->set('sum = '.$db->quote($sum));
			$query->where('cid = '.$db->quote($id));
			$query->where('service = '.$db->quote(1));
			$db->setQuery( (string)$query );	
			if (!$db->execute()) {
				return false;
			}
			$status = 'thanks';
		}
		else
		{
			$status = 'liked';
		}
	}
}

echo $status;
