<?php
/**
 * @package   	Egolt Archive
 * @link 		http://www.egolt.com
 * @copyright 	Copyright (C) Egolt Foundation - www.egolt.com
 * @author    	Soheil Novinfard
 * @license    	GNU/GPL 2
 *
 * Name:		Egolt Archive
 * License:		GNU/GPL 2
 * Product:		http://www.egolt.com/products/egoltarchive
 */

// Check Joomla! Library and direct access
defined('_JEXEC') or die('Direct access denied!');

jimport('joomla.filesystem.folder');
jimport('joomla.filesystem.file');
 
class pkg_EgoltArchiveInstallerScript
{
	/**
	 * method to install the component
	 *
	 * @return void
	 */
	function install($parent) 
	{
		// $parent is the class calling this method
		$parent->getParent()->setRedirectURL('index.php?option=com_egoltarchive&task=about');
	}
	
	/**
	 * Joomla! pre-flight event
	 * 
	 * @param string $type Installation type (install, update, discover_install)
	 * @param JInstaller $parent Parent object
	 */
	public function preflight($type, $parent)
	{
		// Create Cache Folder
		$f = JPATH_ROOT.'/cache/egoltarchive';
		if(!JFolder::exists($f))
		{
			JFolder::create($f);
		}
		
	}
	
	/**
	 * method to run after an install/update/uninstall method
	 *
	 * @return void
	 */
	function postflight($type, $parent) 
	{
		// Enable Egolt Framework
		$plugin = 'egotrigger';
		$folder = 'system';
		$db = JFactory::getDbo();
		$query = $db->getQuery(true)
					->update($db->qn('#__extensions'))
					->set($db->qn('enabled').' = '.$db->q('1'))
					->where($db->qn('element').' = '.$db->q($plugin))
					->where($db->qn('folder').' = '.$db->q($folder));
		$db->setQuery($query);
		$db->query();
		
		// $parent is the class calling this method
		$parent->getParent()->setRedirectURL('index.php?option=com_egoltarchive&task=about');
	}
}
