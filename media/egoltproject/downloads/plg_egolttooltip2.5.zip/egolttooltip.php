<?php
/**
 * @version		$Id: egolttooltip.php Soheil Novinfard $
 * @package		egolt Tooltip
 * @subpackage  System Plugin
 * @copyright   Copyright (c) egolt Web [International Web Solutions]. All rights reserved.
 * @license     GNU GPL v2.0 or later http://www.gnu.org/licenses/gpl-2.0.html
 */

// No direct access.
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport( 'joomla.html.parameter' );
/**
 * egolttooltip plugin.
 *
 */
 class plgSystemEgoltTooltip extends JPlugin
{
	
	/**
	 * Constructor
	 *
	 * @access      protected
	 * @param       object  $subject The object to observe
	 * @param       array   $config  An array that holds the plugin configuration
	 * @since       2.5
	 */
	public function __construct(& $subject, $config)
	{
		parent::__construct($subject, $config);
		$this->loadLanguage();
		// load plugin parameters
        $this->_plugin = JPluginHelper::getPlugin( 'system', 'egolttooltip' );
        $this->_params = new JParameter( $this->_plugin->params );
		
	}
	function onAfterRoute() {
		$document = &JFactory::getDocument();		
		$juri = &JFactory::getURI();
		$bgcolor=$this->_params->get('bgcolor');
		$brcolor=$this->_params->get('brcolor');
		$txtcolor=$this->_params->get('txtcolor');
		$fontsize=$this->_params->get('fontsize');
		$fontfamily=$this->_params->get('fontfamily');
		$brradius=$this->_params->get('brradius');
		$mymenuitem=$this->_params->get('mymenuitem');
		$app = JFactory::getApplication();
		$menu = $app->getMenu();
		$page=$this->_params->get('page');
		
		if(strpos($juri->getPath(),'/administrator/')!==false) return;
		
		if($value=$this->_params->get('embed')) {
			$document->addScript(JURI::root( true ).'/plugins/system/egolttooltip/egolttooltip/jquery-1.3.2.min.js');
		}
	    switch($page){
		case "0" :$this->enable_tooltip();break;
		case "1" :if (in_array($menu->getActive()->id, $mymenuitem)) $this->enable_tooltip(); break;
		case "2" :if (!in_array($menu->getActive()->id, $mymenuitem)) $this->enable_tooltip(); break;	
		}
		
		if($value=$this->_params->get('noconflict')) {
			$document->addScript(JURI::root( true ).'/plugins/system/egolttooltip/egolttooltip/jquery.noconflict.js');
		}
		
	$style = 'div#qTip {
	background:' . $bgcolor . ';
	border: 2px solid ' . $brcolor . ';
	color: ' . $txtcolor . ';
	font-size: ' . $fontsize . ';
	font-family: ' . $fontfamily . ';
	border-radius: ' . $brradius . ';
	}';
$document->addStyleDeclaration( $style );
	}
	function enable_tooltip(){
		$document = &JFactory::getDocument();
		$document->addScript(JURI::root( true ).'/plugins/system/egolttooltip/egolttooltip/jquery.lib.min.js');
		$document->addScript(JURI::root( true ).'/plugins/system/egolttooltip/egolttooltip/initialize.js');
		$document->addStyleSheet(JURI::root( true ).'/plugins/system/egolttooltip/egolttooltip/egolttooltip.css');
	}
}
