<?php
/**
 * @version		$Id: egolttooltip.php Soheil Novinfard $
 * @package		egolt Tooltip
 * @subpackage  System Plugin
 * @copyright   Copyright (c) egolt Web [International Web Solutions]. All rights reserved.
 * @license     GNU GPL v2.0 or later http://www.gnu.org/licenses/gpl-2.0.html
 */

// No direct access.
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport( 'joomla.html.parameter' );
/**
 * currency plugin.
 *
 */
 class plgSystemEgoltTooltip extends JPlugin
{
	
	/**
	 * Constructor
	 *
	 * @access      protected
	 * @param       object  $subject The object to observe
	 * @param       array   $config  An array that holds the plugin configuration
	 * @since       2.5
	 */
	function plgSystemEgoltTooltip( &$subject, $params )
	{
			parent::__construct( $subject, $params );
			$this->paramObj = new JParameter($params['params']);
	}
	function onAfterRoute() {
		$document = &JFactory::getDocument();		
		$juri = &JFactory::getURI();
		if(strpos($juri->getPath(),'/administrator/')!==false) return;
		
		$bgcolor=$this->paramObj->get('bgcolor');
		$brcolor=$this->paramObj->get('brcolor');
		$txtcolor=$this->paramObj->get('txtcolor');
		$fontsize=$this->paramObj->get('fontsize');
		$fontfamily=$this->paramObj->get('fontfamily');
		$brradius=$this->paramObj->get('brradius');
		$mymenuitem=$this->paramObj->get('mymenuitem');
		if( !is_array($mymenuitem))
		$mymenuitem = explode("|", $mymenuitem);
		$app = JFactory::getApplication();
		$menu = & JSite::getMenu();
		$page=$this->paramObj->get('page');
		
		
		
		if($value=$this->paramObj->get('embed')) {
			$document->addScript(JURI::root( true ).'/plugins/system/egolttooltip/jquery-1.3.2.min.js');
		}
	    switch($page){
		case "0" :$this->enable_tooltip();break;
		case "1" :if (in_array($menu->getActive()->id, $mymenuitem)) $this->enable_tooltip(); break;
		case "2" :if (!in_array($menu->getActive()->id, $mymenuitem)) $this->enable_tooltip(); break;	
		}
		
		if($value=$this->paramObj->get('noconflict')) {
			$document->addScript(JURI::root( true ).'/plugins/system/egolttooltip/jquery.noconflict.js');
		}
		
	$style = 'div#qTip {
	background:' . $bgcolor . ';
	border: 2px solid ' . $brcolor . ';
	color: ' . $txtcolor . ';
	font-size: ' . $fontsize . ';
	font-family: ' . $fontfamily . ';
	border-radius: ' . $brradius . ';
	}';
$document->addStyleDeclaration( $style );
	}
	function enable_tooltip(){
		$document = &JFactory::getDocument();
		$document->addScript(JURI::root( true ).'/plugins/system/egolttooltip/jquery.lib.min.js');
		$document->addScript(JURI::root( true ).'/plugins/system/egolttooltip/initialize.js');
		$document->addStyleSheet(JURI::root( true ).'/plugins/system/egolttooltip/egolttooltip.css');
	}
}
